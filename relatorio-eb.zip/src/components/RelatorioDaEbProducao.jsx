import React, { useState } from "react";

export default function RelatorioDaEbProducao() {
  const [form, setForm] = useState({
    nome: "",
    funcao: "",
    tarefas: "",
    resultados: "",
    desafios: "",
    sugestoes: "",
    mes: "",
    dia: "",
    ano: ""
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = () => {
    alert("Relatório enviado com sucesso!");
    console.log("Relatório submetido:", form);
  };

  return (
    <div className="flex justify-center items-center min-h-screen bg-gray-100 p-5">
      <div className="w-full max-w-2xl p-5 bg-white shadow-2xl rounded-xl">
        <h2 className="text-2xl font-bold text-center mb-4 text-gray-800">RELATÓRIO SEMANAL DE ACOMPANHAMENTO DE PRODUÇÃO</h2>
        <div className="mb-4 flex space-x-4">
          <div>
            <label className="text-gray-600">Dia:</label>
            <input type="number" name="dia" value={form.dia} onChange={handleChange} className="border border-gray-400 rounded p-2 w-full" />
          </div>
          <div>
            <label className="text-gray-600">Mês:</label>
            <input name="mes" value={form.mes} onChange={handleChange} className="border border-gray-400 rounded p-2 w-full" />
          </div>
          <div>
            <label className="text-gray-600">Ano:</label>
            <input type="number" name="ano" value={form.ano} onChange={handleChange} className="border border-gray-400 rounded p-2 w-full" />
          </div>
        </div>
        <div className="mb-4">
          <label className="text-gray-600">Nome:</label>
          <input name="nome" value={form.nome} onChange={handleChange} className="border border-gray-400 rounded p-2 w-full" />
        </div>
        <div className="mb-4">
          <label className="text-gray-600">Função/Setor:</label>
          <input name="funcao" value={form.funcao} onChange={handleChange} className="border border-gray-400 rounded p-2 w-full" />
        </div>
        <div className="mb-4">
          <label className="text-gray-600">Tarefas Concluídas:</label>
          <textarea name="tarefas" value={form.tarefas} onChange={handleChange} className="border border-gray-400 rounded p-2 w-full" />
        </div>
        <div className="mb-4">
          <label className="text-gray-600">Resultados Alcançados:</label>
          <textarea name="resultados" value={form.resultados} onChange={handleChange} className="border border-gray-400 rounded p-2 w-full" />
        </div>
        <div className="mb-4">
          <label className="text-gray-600">Eventuais Desafios ou Pendências:</label>
          <textarea name="desafios" value={form.desafios} onChange={handleChange} className="border border-gray-400 rounded p-2 w-full" />
        </div>
        <div className="mb-4">
          <label className="text-gray-600">Sugestões ou Observações:</label>
          <textarea name="sugestoes" value={form.sugestoes} onChange={handleChange} className="border border-gray-400 rounded p-2 w-full" />
        </div>
        <div className="mt-4 text-center">
          <button onClick={handleSubmit} className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg shadow-md">Enviar Relatório</button>
        </div>
      </div>
    </div>
  );
}
