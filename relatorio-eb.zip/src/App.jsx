import RelatorioDaEbProducao from "./components/RelatorioDaEbProducao";

function App() {
  return <RelatorioDaEbProducao />;
}

export default App;
